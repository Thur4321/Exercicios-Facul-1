
package aleatório;

import java.util.Random;

public class NúmeroAleatório {
    
    private int palpite;
    
    private int valor;
    
    public int getPalpite(){
        return palpite;
    }
    
    public void setPalpite(int advinhação){
        palpite=advinhação;
    
    }

    public int valor(){
        Random aleatório = new Random();
        valor = aleatório.nextInt((9)+1);
        return valor;
    }
    
    public boolean correção(){
        return (valor() == palpite);
    }
    
}
