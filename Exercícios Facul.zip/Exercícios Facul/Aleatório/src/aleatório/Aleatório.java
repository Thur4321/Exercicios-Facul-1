
package aleatório;

import javax.swing.JOptionPane;

public class Aleatório {

    public static void main(String[] args) {
   
    int palpite=Integer.parseInt(JOptionPane.showInputDialog(null,"Qual seu palpite?","Advinhação",3));
    int tentativa = 1;
    
    NúmeroAleatório objPalpite = new NúmeroAleatório();
       
    objPalpite.setPalpite(palpite);
    
    if (objPalpite.correção() == true){
            JOptionPane.showMessageDialog(null,"Parabéns! Você acertou em "+tentativa+" tentativas.","Advinhação",1);
        }  
    else{
        while (objPalpite.correção() == false){
          JOptionPane.showMessageDialog(null," Você errou","Advinhação",1);
          palpite=Integer.parseInt(JOptionPane.showInputDialog(null,"Se quiser tentar novamente, digite outro palpite, se não, clique em cancelar.","Advinhação",3)); 
          objPalpite.setPalpite(palpite);
          tentativa++;
        }
    }
    }
}
