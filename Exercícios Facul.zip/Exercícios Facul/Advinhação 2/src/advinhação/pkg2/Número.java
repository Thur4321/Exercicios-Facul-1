
package advinhação.pkg2;

public class Número {

    public class Jogo {
    private int num;
    private int aleatorio;
    private int tentativas=1;

    public int getNum() {
        return num;
    }

    public void setNum(int numero) {
    num = numero;
    }

    public int getAleatorio() {
        return aleatorio;
    }

    public void setAleatorio(int aleatorio1) {
      aleatorio = aleatorio1;
    }

    public int getTentativas() {
        return tentativas;
    }

    public void setTentativas(int tentativas1) {
        tentativas = tentativas1;
    }

    public int numeroAleatorio(){
        aleatorio=(int)(1+Math.random()*10);
    return aleatorio;
    }
    
    public String jogo(){
        if(aleatorio<num){
        return "Tente um número maior";
        
    } else if(aleatorio>num){
 
        return "Tente um número menor";
         
    }
    else if(num==aleatorio){
        return "Acertou";
    }
    return null;
    
    }
    }
}



