
package advinhação.pkg2;

import javax.swing.JOptionPane;

public class Advinhação2 {

    public static void main(String[] args) {
        
    int num=Integer.parseInt(JOptionPane.showInputDialog(null,"Qual seu palpite?"));
    
    int tentativa=1;
    
    
    Número valor = new Número();
    valor.setNum(num);
            
  
    while(num!=tentativa){
          JOptionPane.showMessageDialog(null, "teste" + valor.jogo());
          num=Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o número"));
          tentativa++;
          JOptionPane.showMessageDialog(null, "teste" + valor.jogo());
}
    }
    
}
