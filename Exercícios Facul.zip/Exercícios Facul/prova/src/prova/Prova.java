
package prova;

public class Prova {

    public static void main(String[] args) {
        
        Dog obj = new Dog();   
    }
    
}
