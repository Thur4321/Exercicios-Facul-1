
package prova;

public class Dog {
    
}
