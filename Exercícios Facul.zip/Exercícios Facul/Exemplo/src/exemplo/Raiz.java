
package exemplo;

public class Raiz {
    
        public String raizes(){
        double x1 = 0, x2 = 0, delta = 10;
        x1 = 10 * delta;
        x2 = delta * 5;
        return "[" + x1 + ", " + x2 + "]";
    }
}
