
package exemplo;

import javax.swing.JOptionPane;

public class Exemplo {

    public static void main(String[] args) {
        
        Raiz raiz = null;
        
        JOptionPane.showMessageDialog(null, raiz.raizes(), "Raiz", 0);
    }
    
}
